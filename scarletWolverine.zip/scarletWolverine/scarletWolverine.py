#User ID: ScarletWolverine
#Edited: 2/28/2021
#Challenge No. 1
#Citations: Various (read: tons of) StackOverflow forums for bugs
#           "Data Science from Scratch" by Joel Grus
#           Professional insight from Riley Blaylock and J. Adam Jones, PhD


import matplotlib.pyplot as mplot

#Open data and read, replace spaces with no spaces and split by new line
data = open("ScarletWolverine_ch1.csv", "r")
data = data.read()
data = data.replace(" ", "")
data = data.split("\n")

#Establish x-axis and y-axis lists
xaxis = []
yaxis = []

#Removes extraneous row
data.pop()     
        
#Index my data list by comma
for index in range(0, len(data)): 
    data[index] = data[index].split(",")            
                                            
    #55.209365 was not the correct frequency, it was the other one
    #Append the timestamps and amplitudes to the x and y axes for scatter
    if data[index][2] != "55.209365":
        xaxis.append(float(data[index][0]))
        yaxis.append(float(data[index][1])) 
   
#Create a new list of just the timestamps and frequencies
newlist = list(zip(xaxis, yaxis))

#Establish x and y lists for the line plot
#Prepare a list for taking averages
xline = []
yline = []
sumlist = []

#Append unique timestamps to new x-axis list
for x in xaxis:
    if x not in xline:
        xline.append(float(x))

#Compare unique timestamps to the timestamps in my zipped list
#If they match, append the corresponding amplitudes to the sum list
for i in range(0, len(xline)):
    for y in range(0, len(newlist)):
        
        if xline[i] == newlist[y][0]:
            sumlist.append(newlist[y][1])
            
    #Use the sumlist to take the average for each timestamp
    #and clear it before each new timestamp
    avg = sum(sumlist)/len(sumlist)
    yline.append(avg)
    sumlist.clear()

#Plot the data in both a scatter plot and line plot
mplot.xlabel("Timestamp") 
mplot.ylabel("Amplitude")      
mplot.scatter(xaxis, yaxis, color="red")        
mplot.plot(xline, yline, color="blue")
mplot.show()
    





